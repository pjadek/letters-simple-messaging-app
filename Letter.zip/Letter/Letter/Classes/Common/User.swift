//
//  User.swift
//  Letter
//
//  Created by Petar Jadek on 04/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import Foundation

class UserList {
    
    var id: String!
    var username: String!
    var name: String!
    var initials: String!
    var color: String!
    
    init(id: String, username: String, name: String, initials: String, color: String) {
        self.id = id
        self.username = username
        self.name = name
        self.initials = initials
        self.color = color
    }
    
}
