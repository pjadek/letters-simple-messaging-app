//
//  AccountColor.swift
//  Letter
//
//  Created by Petar Jadek on 07/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import Foundation

class AccountColor {
    let colors = ["244,66,66", "147,16,84", "79,16,147", "16,44,147", "16,147,130", "205,114,18", "18,132,204", "89,89,89"]
    
    public func randomColor() -> String {
        return colors.randomElement()!
    }
}
