//
//  Switcher.swift
//  Letter
//
//  Created by Petar Jadek on 28/12/2018.
//  Copyright © 2018 Petar Jadek. All rights reserved.
//

import Foundation
import UIKit

class Switcher {
    
    static func updateRootViewController() {
        let status = UserDefaults.standard.bool(forKey: "status")
        var rootViewController: UIViewController?
        
        if (status) {
            rootViewController = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()
        } else {
            rootViewController = UIStoryboard(name: "Login", bundle: nil).instantiateInitialViewController()
        }
        
        DispatchQueue.main.async {
            let delegate = UIApplication.shared.delegate as! AppDelegate
            delegate.window?.rootViewController = rootViewController
        }
    }
    
}
