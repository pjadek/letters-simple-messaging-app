//
//  Message.swift
//  Letter
//
//  Created by Petar Jadek on 05/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import Foundation

class Message {
    var sender: String!
    var reciever: String!
    var message: String!
    var date: Int!
    var seen: Int!
    
    init(sender: String, reciever: String, message: String, date: Int, seen: Int) {
        self.sender = sender
        self.reciever = reciever
        self.message = message
        self.date = date
        self.seen = seen
    }
}
