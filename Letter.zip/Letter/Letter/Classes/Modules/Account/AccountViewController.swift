//
//  AccountViewController.swift
//  Letter
//
//  Created by Petar Jadek on 02/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class AccountViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.rightBarButtonItem = self.editButtonItem
        
    }
    
    
}
