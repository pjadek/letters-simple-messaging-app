//
//  AccountTableViewController.swift
//  Letter
//
//  Created by Petar Jadek on 03/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class AccountTableViewController: UITableViewController {
    
    
    @IBOutlet weak var firstnameLastnameLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var firstnameTextField: UITextField!
    @IBOutlet weak var lastnameTextField: UITextField!
    @IBOutlet weak var telephoneTextField: UITextField!
    @IBOutlet weak var initialsLabel: UILabel!
    @IBOutlet weak var initialsView: UIView!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    @IBOutlet weak var currentPassword: UITextField!
    @IBOutlet weak var newPassword: UITextField!
    @IBOutlet weak var repeatNewPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        emailTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        firstnameTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        lastnameTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        telephoneTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        saveButton.isEnabled = false
        
        let username = UserDefaults.standard.string(forKey: "username")
        let url = URL(string: "http://127.0.0.1:5984/letter/user-\(username!)")
        self.loadData(url: url!)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        saveButton.isEnabled = true
    }
    
    private func loadData(url: URL) {
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    
                    DispatchQueue.main.async {
                        
                        if (String(describing: serverData["firstname"]!).isEmpty || String(describing: serverData["lastname"]!).isEmpty) {
                            self.firstnameLastnameLabel.text = "\(String(describing: serverData["username"]!))"
                        } else {
                            self.firstnameLastnameLabel.text = "\(String(describing: serverData["firstname"]!)) \(String(describing: serverData["lastname"]!))"
                            self.firstnameTextField.text = String(describing: serverData["firstname"]!)
                            self.lastnameTextField.text = String(describing: serverData["lastname"]!)
                        }
                        
                        self.usernameLabel.text = String(describing: serverData["username"]!)
                        self.emailTextField.text = String(describing: serverData["email"]!)
                        self.telephoneTextField.text = String(describing: serverData["telephone"]!)
                        
                        let initialsFN = String(describing: serverData["firstname"]!)
                        let initialsLN = String(describing: serverData["lastname"]!)
                        self.initialsLabel.textColor = UIColor.white
                        self.initialsLabel.text = "\(initialsFN.prefix(1))\(initialsLN.prefix(1))"
                        
                        let colors = String(describing: serverData["color"]!).split(separator: ",")
                        print(colors)
                        let color = UIColor(red: CGFloat(Float(colors[0])! / 255.0), green: CGFloat(Float(colors[1])! / 255.0), blue: CGFloat(Float(colors[2])! / 255.0), alpha: 1.0)
                        
                        self.initialsView.layer.backgroundColor = color.cgColor
                        self.initialsView.layer.cornerRadius =  27.5
                        
                    }
                }
                
            }
        )
    }
    
    @IBAction func logout(_ sender: Any) {
        UserDefaults.standard.set(false, forKey: "status")
        Switcher.updateRootViewController()
    }
    
    @IBAction func update(_ sender: Any) {
        let username = UserDefaults.standard.string(forKey: "username")
        let url = URL(string: "http://127.0.0.1:5984/letter/user-\(username!)")
        
        Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    let color = AccountColor().randomColor()
                    let parameters: Parameters = [
                        "firstname": self.firstnameTextField.text!,
                        "lastname": self.lastnameTextField.text!,
                        "username": self.usernameLabel.text!,
                        "email": self.emailTextField.text!,
                        "password": serverData["password"]!,
                        "telephone": self.telephoneTextField.text!,
                        "_rev": serverData["_rev"]!,
                        "color": color
                    ]
                    
                    self.updateUserData(url: url!, data: parameters)
                    
                }
                
            }
        )
    }
    
    private func updateUserData(url: URL, data: Parameters)  {
        Alamofire.request(url, method: .put, parameters: data, encoding: JSONEncoding.default)
        .responseJSON(completionHandler: { (response) in
            
            if let serverData = response.result.value! as? NSDictionary {
                if ((serverData["ok"]) != nil) {
                    self.saveButton.isEnabled = false
                    self.loadData(url: url)
                }
            }
        }
        )
    }
    
    @IBAction func changePassword(_ sender: Any) {
        
        if (self.currentPassword.text!.isEmpty || self.newPassword.text!.isEmpty || self.repeatNewPassword.text!.isEmpty) {
            printAlert(title: "Missing Information", message: "All fields have to be filled to change password.")
        } else {
            if (self.newPassword.text! != self.repeatNewPassword.text!) {
                printAlert(title: "Passwords do not match", message: "Passwords must match to change password.")
            } else {
                
                let username = UserDefaults.standard.string(forKey: "username")
                let url = URL(string: "http://127.0.0.1:5984/letter/user-\(username!)")
                
                Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default)
                    .responseJSON(completionHandler: { (response) in
                        
                        if let serverData = response.result.value! as? NSDictionary {
                            let color = AccountColor().randomColor()
                            let parameters: Parameters = [
                                "firstname": self.firstnameTextField.text!,
                                "lastname": self.lastnameTextField.text!,
                                "username": self.usernameLabel.text!,
                                "email": self.emailTextField.text!,
                                "telephone": self.telephoneTextField.text!,
                                "_rev": serverData["_rev"]!,
                                "color": color,
                                "password": self.repeatNewPassword.text!.hash
                            ]
                            
                            if ("\(serverData["password"]!)" == "\(self.currentPassword.text!.hash)") {
                                self.updatePasswords(url: url!, data: parameters)
                            } else {
                                self.printAlert(title: "Error", message: "Your current password is incorrect.")
                            }
                            
                        }
                        
                    }
                )
                
            }
        }
        
    }
    
    private func updatePasswords(url: URL, data: Parameters)  {
        Alamofire.request(url, method: .put, parameters: data, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    if ((serverData["ok"]) != nil) {
                        self.saveButton.isEnabled = false
                        self.loadData(url: url)
                        self.printAlert(title: "Success", message: "Password is updated.")
                    }
                }
            }
        )
    }
    
    private func printAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    
    @IBAction func deleteAccount(_ sender: Any) {
        let username = UserDefaults.standard.string(forKey: "username")
        let url = URL(string: "http://127.0.0.1:5984/letter/user-\(username!)")

        Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    self.deleteUser(url: URL(string: "http://127.0.0.1:5984/letter/user-\(username!)?rev=\(serverData["_rev"]!)")!)
                
                    
                }
                
            }
        )
    }
    
    private func deleteUser(url: URL) {
        Alamofire.request(url, method: .delete, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                print(response.result.value)
                UserDefaults.standard.set(false, forKey: "status")
                Switcher.updateRootViewController()
                
            }
        )
    }
    
}
