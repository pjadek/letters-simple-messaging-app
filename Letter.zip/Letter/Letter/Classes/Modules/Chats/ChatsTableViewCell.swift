//
//  ChatsTableViewCell.swift
//  Letter
//
//  Created by Petar Jadek on 07/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit

class ChatsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
