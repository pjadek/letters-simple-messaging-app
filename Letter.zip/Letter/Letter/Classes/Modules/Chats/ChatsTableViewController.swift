//
//  ChatsTableViewController.swift
//  Letter
//
//  Created by Petar Jadek on 07/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class ChatsTableViewController: UITableViewController {

    var user: Array<String> = []
    var chats: Array<String> = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()

        loadData(url: URL(string: "http://127.0.0.1:5984/letter/_design/findpeople/_view/chat-view")!)
    }
    
    private func loadData(url: URL) {
        DispatchQueue.main.async {
            Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
                .responseJSON(completionHandler: { (response) in
                    
                    if let serverData = response.result.value! as? NSDictionary {
                        if let userData = serverData["rows"]! as? NSArray {
                            for user in userData {
                                if let listData = user as? NSDictionary {
                                    if let userDocument = listData["value"]! as? NSDictionary {
                                        let reciever = String(describing: userDocument["reciever"]!)
                                        let sender = String(describing: userDocument["sender"]!)
                                        if (UserDefaults.standard.string(forKey: "username")! == sender) {
                                            self.user.append(reciever)
                                        } else if (UserDefaults.standard.string(forKey: "username")! == reciever) {
                                            self.user.append(sender)
                                        }
                                        }
                                    }
                                }
                            }
                        }
                    
                    for item in self.user {
                        if (self.chats.contains(item) == false && item != UserDefaults.standard.string(forKey: "username")!) {
                            self.chats.append(item)
                        }
                    }
                    
                    
                    self.tableView.reloadData()
                }
            )
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.chats.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ChatCellIdentifier", for: indexPath) as? ChatsTableViewCell else {
            fatalError("Error")
        }
       
        cell.nameLabel.text = self.chats[indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "ChatScreen", bundle: nil)
        let chatScreenVC = storyboard.instantiateViewController(withIdentifier: "Chat Screen") as! ChatScreenViewController
        chatScreenVC.usernameTitle.title = self.chats[indexPath.row]
        UserDefaults.standard.set(self.chats[indexPath.row], forKey: "reciever")
        let navigationVc = UINavigationController(rootViewController: chatScreenVC)
        DispatchQueue.main.async {
            self.present(navigationVc, animated: true, completion: nil)
        }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
