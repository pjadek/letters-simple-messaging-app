//
//  MessageTableViewCell.swift
//  Letter
//
//  Created by Petar Jadek on 05/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit

class MessageTableViewCell: UITableViewCell {

    @IBOutlet weak var recieverMessage: UILabel!
    @IBOutlet weak var fromLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
