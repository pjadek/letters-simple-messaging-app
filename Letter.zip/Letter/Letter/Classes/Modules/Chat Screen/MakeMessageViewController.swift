//
//  MakeMessageViewController.swift
//  Letter
//
//  Created by Petar Jadek on 05/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class MakeMessageViewController: UIViewController {

    
    @IBOutlet weak var messageTextField: UITextField!
    @IBOutlet weak var sendButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        messageTextField.layer.borderWidth = 0
        messageTextField.layer.cornerRadius = 15

        if ((messageTextField.text?.isEmpty)!) {
            sendButton.isEnabled = false
        }
        
        messageTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        sendButton.isEnabled = true
    }

    @IBAction func sendMessage(_ sender: Any) {
        let parameters: Parameters = [
            "_id": "chat-\(Date().timeIntervalSince1970)",
            "time": Int(Date().timeIntervalSince1970),
            "reciever": UserDefaults.standard.string(forKey: "reciever")!,
            "sender": UserDefaults.standard.string(forKey: "username")!,
            "message": messageTextField.text!,
            "seen": 0
        ]
        
        Alamofire.request(URL(string: "http://127.0.0.1:5984/letter/chat-\(Date().timeIntervalSince1970)")!, method: .put, parameters: parameters, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    
                    if let message = serverData["ok"] {
                        self.messageTextField.text?.removeAll()
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadTableData"), object: nil)
                    }
                    
                }
                
            }
        )
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
