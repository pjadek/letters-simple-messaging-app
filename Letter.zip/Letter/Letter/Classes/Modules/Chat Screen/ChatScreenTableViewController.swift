//
//  ChatScreenTableViewController.swift
//  Letter
//
//  Created by Petar Jadek on 06/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class ChatScreenTableViewController: UITableViewController {

    var messages: [Message] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
         tableView.tableFooterView = UIView()
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44  

        let messegingUser = UserDefaults.standard.string(forKey: "reciever")!
        let activeUser = UserDefaults.standard.string(forKey: "username")!
        
        NotificationCenter.default.addObserver(self, selector: #selector(reloadTableData(notification:)), name: NSNotification.Name(rawValue: "reloadTableData"), object: nil)
        
        
        self.loadData(sender: activeUser, reciever: messegingUser)
    }
    
    @objc func reloadTableData(notification: NSNotification){
        let messegingUser = UserDefaults.standard.string(forKey: "reciever")!
        let activeUser = UserDefaults.standard.string(forKey: "username")!
        
        messages.removeAll()
        self.loadData(sender: activeUser, reciever: messegingUser)
    }

    
    private func loadData(sender: String, reciever: String) {
        let url = URL(string: "http://127.0.0.1:5984/letter/_design/findpeople/_view/messages-view")
        
        DispatchQueue.main.async {
            Alamofire.request(url!, method: .get, parameters: nil, encoding: JSONEncoding.default)
                .responseJSON(completionHandler: { (response) in
                    if let serverData = response.result.value! as? NSDictionary {
                        if let userData = serverData["rows"]! as? NSArray {
                            for user in userData {
                                if let listData = user as? NSDictionary {
                                    if let message = listData["value"]! as? NSDictionary {
                                        
                                        if ((String(describing: message["sender"]!) == sender && String(describing: message["reciever"]!) == reciever) || (String(describing: message["sender"]!) == reciever && String(describing: message["reciever"]!) == sender)) {
                                            let msg = Message(sender: message["sender"]! as! String, reciever: message["reciever"]! as! String, message: message["message"]! as! String, date: message["time"]! as! Int, seen: message["seen"]! as! Int)
                                            
                                            self.messages.append(msg)
                                            
                                        }
                                        
                                    }
                                }
                            }
                        }
                    }
                    self.tableView.reloadData()
                }
            )
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.messages.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "MessageCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MessageTableViewCell else {
            fatalError("Error")
        }
        
        if (UserDefaults.standard.string(forKey: "username")! == self.messages[indexPath.row].sender!) {
            cell.fromLabel.text = "Sent by \(self.messages[indexPath.row].sender!)"
            cell.recieverMessage.text = self.messages[indexPath.row].message!

        } else {
            cell.fromLabel.text = "Sent by \(self.messages[indexPath.row].sender!)"
            cell.recieverMessage.text = self.messages[indexPath.row].message!
        }
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
