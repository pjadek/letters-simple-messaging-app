//
//  RegistrationTableViewController.swift
//  Letter
//
//  Created by Petar Jadek on 02/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class RegistrationTableViewController: UITableViewController {
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var firstnameTextField: UITextField!
    @IBOutlet weak var lastnameTextField: UITextField!
    @IBOutlet weak var telephoneTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var repeatPasswordTextField: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
    @IBAction func register(_ sender: Any) {
        
        if (usernameTextField.text!.isEmpty || emailTextField.text!.isEmpty || passwordTextField.text!.isEmpty || repeatPasswordTextField.text!.isEmpty || firstnameTextField.text!.isEmpty || lastnameTextField.text!.isEmpty) {
            DispatchQueue.main.async {
                self.printAlert(title: "Missing Information", message: "You must enter username, first name, last name, email, password and repeat password fields to continue.")
            }
        } else {
            if (passwordTextField.text != repeatPasswordTextField.text) {
                DispatchQueue.main.async {
                    self.printAlert(title: "Registration Error", message: "Passwords do not match.")
                }
            } else {
                let userUrl = URL(string: "http://127.0.0.1:5984/letter/user-\(usernameTextField.text!)")
                self.checkIfUserExists(url: userUrl!)
            }
        }
        
        
    }
    
    private func printAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    private func checkIfUserExists(url: URL) {
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    if let error = serverData["error"] {
                        self.registerNewUser(url: url)
                    }
                    if let error = serverData["username"] {
                        DispatchQueue.main.async {
                            self.printAlert(title: "Registration Error", message: "User with entered username already exists.")
                        }
                    }
                }
                
            }
        )
    }
    
    private func registerNewUser(url: URL) {
        let paramethers: Parameters = [
            "username": usernameTextField.text!,
            "password": passwordTextField.text!.hash,
            "firstname": firstnameTextField.text!,
            "lastname": lastnameTextField.text!,
            "email": emailTextField.text!,
            "telephone": telephoneTextField.text!,
            "color": AccountColor().randomColor()
        ]
        
        Alamofire.request(url, method: .put, parameters: paramethers, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
                
                if let serverData = response.result.value! as? NSDictionary {
                    if let message = serverData["ok"] {
                        DispatchQueue.main.async {
                            self.printAlert(title: "Success!", message: "You have registered to the application. Please log in to continue.")
                        }
                        Switcher.updateRootViewController()
                    }
                }
            }
        )
    }
    
}
