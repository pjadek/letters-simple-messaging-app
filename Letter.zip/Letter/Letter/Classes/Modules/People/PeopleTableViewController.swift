//
//  PeopleTableViewController.swift
//  Letter
//
//  Created by Petar Jadek on 04/01/2019.
//  Copyright © 2019 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class PeopleTableViewController: UITableViewController {
    
    var list: [UserList] = []
    let searchController = UISearchController(searchResultsController: nil)
    var filteredList = [UserList]()
    
    @IBOutlet weak var peopleTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()

        loadData(url: URL(string: "http://127.0.0.1:5984/letter/_design/findpeople/_view/people-view")!)
        
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Find People"
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }

    private func loadData(url: URL) {
        DispatchQueue.main.async {
            Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
                .responseJSON(completionHandler: { (response) in
                    
                    if let serverData = response.result.value! as? NSDictionary {
                        if let userData = serverData["rows"]! as? NSArray {
                            for user in userData {
                                if let listData = user as? NSDictionary {
                                    if let userDocument = listData["value"]! as? NSDictionary {
                                        let initialsFN = String(describing: userDocument["firstname"]!)
                                        let initialsLN = String(describing: userDocument["lastname"]!)
                                    
                                        let userList = UserList(id: userDocument["_id"]! as! String, username: userDocument["username"]! as! String, name: "\(userDocument["firstname"]!) \(userDocument["lastname"]!)", initials: "\(initialsFN.prefix(1))\(initialsLN.prefix(1))", color: userDocument["color"]! as! String)
                                        
                                        let username = UserDefaults.standard.string(forKey: "username")
                                        if (username! !=  userList.username!) {
                                            self.list.append(userList)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    self.tableView.reloadData()
                }
            )
        }
    }
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering() {
            return filteredList.count
        }
        return self.list.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PeopleCellIdentifier", for: indexPath) as? PeopleTableViewCell else {
            fatalError("Error")
        }
        let fList: UserList
        if isFiltering() {
            fList = filteredList[indexPath.row]
        } else {
            fList = list[indexPath.row]
        }
        
        let colors = fList.color.split(separator: ",")
        let color = UIColor(red: CGFloat(Float(colors[0])! / 255.0), green: CGFloat(Float(colors[1])! / 255.0), blue: CGFloat(Float(colors[2])! / 255.0), alpha: 1.0)
        
        cell.initialsView.layer.backgroundColor = color.cgColor
        cell.initialsView.layer.cornerRadius =  27.5
        
        
        cell.initialsLabel.text = fList.initials!
        cell.initialsLabel.textColor = UIColor.white
        
        cell.nameLabel.text = fList.name!
        cell.usernameEmailLabel.text = fList.username!

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "ChatScreen", bundle: nil)
        let chatScreenVC = storyboard.instantiateViewController(withIdentifier: "Chat Screen") as! ChatScreenViewController
        chatScreenVC.usernameTitle.title = self.list[indexPath.row].username!
        UserDefaults.standard.set(self.list[indexPath.row].username!, forKey: "reciever")
        let navigationVc = UINavigationController(rootViewController: chatScreenVC)
        DispatchQueue.main.async {
            self.present(navigationVc, animated: true, completion: nil)
        }
    }
    
    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        filteredList = list.filter({( userList: UserList) -> Bool in
            return userList.name.lowercased().contains(searchText.lowercased())
        })
        
        tableView.reloadData()
    }
    
    func isFiltering() -> Bool {
        return searchController.isActive && !searchBarIsEmpty()
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PeopleTableViewController: UISearchResultsUpdating  {
    // MARK: - UISearchResultsUpdating Delegate
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)
    }
}

