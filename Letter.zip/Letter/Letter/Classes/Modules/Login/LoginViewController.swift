//
//  LoginViewController.swift
//  Letter
//
//  Created by Petar Jadek on 28/12/2018.
//  Copyright © 2018 Petar Jadek. All rights reserved.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController {
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func login(_ sender: Any) {
        let username = usernameTextField.text!
        let password = String(passwordTextField.text!.hash)
        
        let serviceUrl = URL(string: "http://127.0.0.1:5984/letter/user-\(username)")
        
        Alamofire.request(serviceUrl!, method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON(completionHandler: { (response) in
            
                if let serverData = response.result.value! as? NSDictionary {
                    self.checkOutputData(userData: serverData as! [String : Any], password: password)
                }
           
            }
        )
    }
    
    private func checkOutputData(userData data: [String: Any], password: String) {
        if let error = data["error"] {
            DispatchQueue.main.async {
                self.printAlert(title: "Login Error", message: "User with username \(self.usernameTextField.text!) does not exists.")
            }
        }
        
        if let user = data["username"] {
            if (String(describing: data["password"]!) == password) {
                UserDefaults.standard.set(true, forKey: "status")
                UserDefaults.standard.set(self.usernameTextField.text!, forKey: "username")
                Switcher.updateRootViewController()
            } else {
                DispatchQueue.main.async {
                    self.printAlert(title: "Login Error", message: "Password is incorrect.")
                }
            }
        }
    }
    
    private func printAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
}
